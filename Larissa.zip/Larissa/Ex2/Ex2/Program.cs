﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 0;
            for (int i=0; i<100; i++)
            {
                if (i % 3 == 0)
                {
                    Console.WriteLine(i + " é múltimo de 3!");
                }
            }

            Console.ReadKey();
        }

    }
}
