﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex3
{
    class Program
    {
        int j = 0;
        static void Main(string[] args)
        {
            int fatorial = 1;
            for (int n = 1; n <= 10; n++)
            {

                while (n >= 2)
                {
                    fatorial = fatorial * n;
                    break;
                }
                Console.WriteLine("Fatorial de " + n + " = " + fatorial);
            }
            Console.ReadKey();
        }
    }
}
